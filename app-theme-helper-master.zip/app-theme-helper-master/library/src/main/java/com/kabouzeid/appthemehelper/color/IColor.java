package com.kabouzeid.appthemehelper.color;

/**
 * Created by mikepenz on 07.07.15.
 */
public interface IColor {
    String getAsString();

    int getAsColor();

    int getAsResource();
}
